import { inngest } from '@/lib/inngest/client'
import { createServiceClient } from '@/lib/supabase/server'
import { resend, FROM } from '@/lib/resend/client'

/**
 * Triggered when a crew member submits an inventory count.
 *
 * Steps:
 *  1. Apply the count — update current_quantity on each item
 *  2. Find items below par threshold
 *  3. If any below par, generate a purchase order and email the PM
 */
export const handleInventoryCountSubmitted = inngest.createFunction(
  {
    id:      'inventory-count-submitted',
    name:    'Process Inventory Count',
    retries: 2,
  },
  { event: 'inventory/count-submitted' as const },
  async ({ event, step, logger }) => {
    const { count_id, property_id, org_id } = event.data
    const supabase = createServiceClient()

    // ── Apply the count to inventory_items ──────────────────────────────────

    const { belowParItems } = await step.run('apply-count-and-check-par', async () => {
      // Fetch count items
      const { data: countItems } = await supabase
        .from('inventory_count_items')
        .select('inventory_item_id, quantity_counted')
        .eq('count_id', count_id)

      if (!countItems?.length) return { belowParItems: [] }

      const below: Array<{
        id: string; name: string; category: string; unit: string
        par_level: number; current_quantity: number; quantity_to_buy: number
      }> = []

      for (const item of countItems) {
        // Update current_quantity
        await supabase
          .from('inventory_items')
          .update({ current_quantity: item.quantity_counted })
          .eq('id', item.inventory_item_id)

        // Fetch full item to check against par
        const { data: inv } = await supabase
          .from('inventory_items')
          .select('id, name, category, unit, par_level, low_stock_threshold_pct')
          .eq('id', item.inventory_item_id)
          .single()

        if (!inv) continue

        const threshold = Math.ceil(inv.par_level * (inv.low_stock_threshold_pct / 100))
        if (item.quantity_counted <= threshold) {
          const quantityToBuy = inv.par_level - item.quantity_counted
          below.push({
            id:               inv.id,
            name:             inv.name,
            category:         inv.category,
            unit:             inv.unit,
            par_level:        inv.par_level,
            current_quantity: item.quantity_counted,
            quantity_to_buy:  quantityToBuy,
          })
        }
      }

      return { belowParItems: below }
    })

    if (belowParItems.length === 0) {
      logger.info(`Count ${count_id}: all items at or above par`)
      return { count_id, purchaseOrderCreated: false }
    }

    logger.info(`Count ${count_id}: ${belowParItems.length} items below par — generating PO`)

    // ── Generate purchase order ──────────────────────────────────────────────

    const purchaseOrderId = await step.run('create-purchase-order', async () => {
      const { data: po } = await supabase
        .from('purchase_orders')
        .insert({
          property_id:          property_id,
          org_id:               org_id,
          status:               'draft',
          total_estimated_cost: null,  // no unit costs at this stage
        })
        .select('id')
        .single()

      if (!po) throw new Error('Failed to create purchase order')

      await supabase.from('purchase_order_items').insert(
        belowParItems.map((item) => ({
          purchase_order_id: po.id,
          inventory_item_id: item.id,
          item_name:         item.name,
          current_quantity:  item.current_quantity,
          par_level:         item.par_level,
          quantity_to_buy:   item.quantity_to_buy,
        }))
      )

      // Mark PO as sent
      await supabase
        .from('purchase_orders')
        .update({ status: 'sent', sent_at: new Date().toISOString() })
        .eq('id', po.id)

      return po.id
    })

    // ── Email PM with PO summary ─────────────────────────────────────────────

    await step.run('email-po-to-pm', async () => {
      const [{ data: property }, { data: adminMember }] = await Promise.all([
        supabase.from('properties').select('name').eq('id', property_id).single(),
        supabase.from('organization_members').select('user_id').eq('org_id', org_id).eq('role', 'admin').single(),
      ])

      let pmEmail: string | null = null
      if (adminMember?.user_id) {
        const { data: { user } } = await supabase.auth.admin.getUserById(adminMember.user_id)
        pmEmail = user?.email ?? null
      }

      if (!pmEmail) return

      const itemRows = belowParItems
        .map((item) => `
          <tr>
            <td style="padding:8px;border-bottom:1px solid #e2e8f0">${item.name}</td>
            <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center">${item.current_quantity} ${item.unit}</td>
            <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center">${item.par_level} ${item.unit}</td>
            <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:center;font-weight:600;color:#093b31">${item.quantity_to_buy} ${item.unit}</td>
          </tr>
        `)
        .join('')

      await resend.emails.send({
        from:    FROM,
        to:      pmEmail,
        subject: `📦 Restock needed — ${property?.name} (${belowParItems.length} item${belowParItems.length !== 1 ? 's' : ''})`,
        html: `
          <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
            <h2>Inventory below par at ${property?.name}</h2>
            <p>A crew member just submitted an inventory count. The following items need restocking:</p>
            <table style="border-collapse:collapse;width:100%;margin:16px 0">
              <thead>
                <tr style="background:#f1f5f9">
                  <th style="padding:10px 8px;text-align:left;font-size:12px;color:#64748b;text-transform:uppercase">Item</th>
                  <th style="padding:10px 8px;text-align:center;font-size:12px;color:#64748b;text-transform:uppercase">In Stock</th>
                  <th style="padding:10px 8px;text-align:center;font-size:12px;color:#64748b;text-transform:uppercase">Par Level</th>
                  <th style="padding:10px 8px;text-align:center;font-size:12px;color:#64748b;text-transform:uppercase">Need to Buy</th>
                </tr>
              </thead>
              <tbody>${itemRows}</tbody>
            </table>
            <p style="color:#64748b;font-size:14px">Order however works best for you — Amazon, local store, or your usual supplier.</p>
            <p><a href="${process.env.NEXT_PUBLIC_APP_URL}/inventory?property=${property_id}&po=${purchaseOrderId}" style="background:#093b31;color:white;padding:10px 20px;text-decoration:none;border-radius:6px;display:inline-block">View Purchase Order →</a></p>
          </div>
        `,
      })
    })

    return { count_id, purchaseOrderCreated: true, purchaseOrderId, itemCount: belowParItems.length }
  }
)
