# FieldStay

STR operations platform for property managers.  
Built with Next.js 15, Supabase, Inngest, PowerSync, and Resend.

---

## Stack

| Layer         | Tech                    |
|---------------|-------------------------|
| Framework     | Next.js 15 (App Router) |
| Database      | Supabase (Postgres + RLS) |
| Auth          | Supabase Auth           |
| Storage       | Supabase Storage        |
| Background jobs | Inngest               |
| Offline sync  | PowerSync               |
| Email         | Resend                  |
| Payments      | Stripe                  |
| Hosting       | Vercel                  |

---

## First-time Setup

### 1. Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste and run `fieldstay_migration_v1.sql`
3. Go to **Storage** → create buckets:
   - `turnover-photos` (public)
   - `work-order-photos` (public)
   - `crew-uploads` (public)
4. Copy your Project URL and keys from **Settings → API**

### 2. Inngest

1. Create an account at [inngest.com](https://inngest.com)
2. Create an app named `fieldstay`
3. Copy the Event Key and Signing Key from **Manage → Keys**

### 3. Resend

1. Create an account at [resend.com](https://resend.com)
2. Add and verify your domain (`fieldstay.com`)
3. Create an API key

### 4. Stripe

1. Create products and prices in the Stripe dashboard
2. Note the Price IDs for Starter, Growth, and Pro plans
3. Set up a webhook endpoint pointing to:
   `https://app.fieldstay.com/api/webhooks/stripe`
   Events to listen for:
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`

### 5. PowerSync

1. Create an account at [powersync.com](https://powersync.com)
2. Connect your Supabase instance
3. Copy your instance URL

### 6. Environment

```bash
cp .env.example .env.local
# Fill in all values
```

### 7. Install & Run

```bash
npm install
npm run dev
```

For Inngest local dev (in a second terminal):
```bash
npm run inngest:dev
```

---

## Deployment (Vercel)

1. Push to GitHub
2. Import repo in Vercel
3. Add all environment variables from `.env.example`
4. Deploy

---

## Project Structure

```
fieldstay/
├── app/
│   ├── (auth)/           # Login, signup — public
│   ├── (dashboard)/      # PM + manager views — auth required
│   │   ├── properties/
│   │   ├── turnovers/
│   │   ├── inventory/
│   │   ├── maintenance/
│   │   ├── communications/
│   │   ├── owners/
│   │   └── settings/
│   ├── crew/             # Crew PWA — offline via PowerSync
│   ├── owner/[token]/    # Owner portal — tokenized, no login
│   └── api/
│       ├── inngest/      # Inngest webhook handler
│       ├── webhooks/stripe/
│       └── work-orders/[token]/complete/
├── lib/
│   ├── supabase/         # Server, client, middleware clients
│   ├── inngest/          # Client + all event type definitions
│   ├── resend/           # Email client + template renderer
│   └── stripe/           # Stripe client + plan definitions
├── types/
│   └── database.ts       # TypeScript types for all DB tables
└── components/           # Shared UI components (to be built)
```

---

## Feature Build Order (recommended)

1. ✅ Schema + migration
2. ✅ Next.js scaffold (this)
3. ⬜ Inngest: iCal sync function
4. ⬜ Properties CRUD + onboarding wizard
5. ⬜ Turnovers board
6. ⬜ Inngest: guest messaging
7. ⬜ Checklist builder + instance flow
8. ⬜ Crew app (PowerSync offline)
9. ⬜ Inventory + PO generation
10. ⬜ Work orders + vendor portal
11. ⬜ Maintenance schedules
12. ⬜ Owner portal + P&L
13. ⬜ Billing (Stripe checkout)
