import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  experimental: {
    // Required for PowerSync WASM module
    serverComponentsExternalPackages: ['@powersync/web'],
  },
  webpack: (config, { isServer }) => {
    // PowerSync requires WASM support
    config.experiments = {
      ...config.experiments,
      asyncWebAssembly: true,
      layers: true,
    }
    // Suppress PowerSync WASM warnings in server builds
    if (isServer) {
      config.output = {
        ...config.output,
        webassemblyModuleFilename: './../static/wasm/[modulehash].wasm',
      }
    }
    return config
  },
  images: {
    remotePatterns: [
      {
        // Supabase Storage
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },
}

export default nextConfig
